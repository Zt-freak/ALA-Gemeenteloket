<?php
    
?>
<html>
    <head>
        <link rel="stylesheet" href="css/defaultstyles.css">
        <link rel="icon" href="images/favicon.ico" type="image/gif" sizes="64x64">
    </head>
    <body>
        <?php
            require_once('navMenu.php');
        ?>
        <div class="content">
            <div id ="content" class="contentContainer">
                <h1>Geprenked!</h1>
                <p>Wat? had je een speciale Arno CSS verwacht, ofzo?</p>
                <div style="width:1px; height: 50%;"></div>
            </div>
        </div>
        <footer>
            <div class="footerImageContainer">
            </div>
        </footer>
    </body>
</html>